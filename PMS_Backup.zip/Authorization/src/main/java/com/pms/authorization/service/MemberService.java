package com.pms.authorization.service;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.pms.authorization.model.AuthenticationRequest;
import com.pms.authorization.repository.AuthenticationRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MemberService implements UserDetailsService, CommandLineRunner {
	
	@Autowired
	private AuthenticationRepository repository;
	
	
	public MemberService(AuthenticationRepository repository) {
		this.repository=repository;
	}
	
	public MemberService() {
	}

	List<AuthenticationRequest> membersList = new ArrayList<AuthenticationRequest>();
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return new User(username, getUserPassword(username), new ArrayList<>());
	}

	

	public String getUserPassword(String username) {
		if(repository.existsById(username)){
			if (log.isDebugEnabled()) log.debug(username+" Found");
			return repository.findByUsername(username).getPassword();
		}
		if(log.isInfoEnabled()) log.info(username+" Not Found");
		return "Not Found";
	}

	public List<AuthenticationRequest> loadMembers(){
		List<AuthenticationRequest> membersList = new ArrayList<AuthenticationRequest>();
		try {
			CSVReader reader = new CSVReaderBuilder(new FileReader("src/main/resources/members.csv")).build();
			membersList = reader.readAll().stream().map(data -> {
				AuthenticationRequest request = new AuthenticationRequest();
				request.setUsername(data[0]);
				request.setPassword(data[1]);
				repository.save(request);
				if(log.isInfoEnabled()) log.info(request.toString());
				return request;
			}).collect(Collectors.toList());
		} catch (IOException e) {
			if(log.isInfoEnabled()) log.info("Unable to Load data from members.csv ");
		}
		return membersList;
	}
	
	@Override
	public void run(String... args) throws Exception {
		membersList=loadMembers();
	}

}
