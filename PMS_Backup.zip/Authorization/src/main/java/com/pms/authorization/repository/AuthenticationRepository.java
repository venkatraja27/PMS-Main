package com.pms.authorization.repository;

import org.springframework.data.repository.CrudRepository;

import com.pms.authorization.model.AuthenticationRequest;

public interface AuthenticationRepository extends CrudRepository<AuthenticationRequest, String> {
	AuthenticationRequest findByUsername(String username);
}
