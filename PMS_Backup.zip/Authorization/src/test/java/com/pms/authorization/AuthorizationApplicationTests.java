package com.pms.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationApplicationTests {

	@Test
	public void applicationContextLoaded() {
	}

}
