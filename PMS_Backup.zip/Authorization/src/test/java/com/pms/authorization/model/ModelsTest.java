package com.pms.authorization.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class ModelsTest {

	@Test
	public void authenticationRequestPositive() {
		AuthenticationRequest request1 = new AuthenticationRequest("admin", "admin");
		AuthenticationRequest request2 = new AuthenticationRequest();
		request2.setUsername("admin");
		request2.setPassword("admin");
		assertEquals(request1.getUsername(), request2.getUsername());
		assertEquals(request1.getPassword(), request2.getPassword());
		assertEquals(request1.toString(), request2.toString());
	}

	@Test
	public void authenticationRequestNegative() {
		AuthenticationRequest request1 = new AuthenticationRequest("admin2", "admin2");
		AuthenticationRequest request2 = new AuthenticationRequest();
		request2.setUsername("admin");
		request2.setPassword("admin");
		assertNotEquals(request1.getUsername(), request2.getUsername());
		assertNotEquals(request1.getPassword(), request2.getPassword());
		assertNotEquals(request1.toString(), request2.toString());
	}

	@Test
	public void authenticationResponsePositive() {

		AuthenticationResponse response1 = new AuthenticationResponse("someJWTToken");
		AuthenticationResponse response2 = new AuthenticationResponse("someJWTToken");
		assertEquals(response1.getJwt(), response2.getJwt());

	}

}
