//package com.pms.pensionerdetail;
//
//import static org.junit.Assert.assertEquals;
//import static org.mockito.Mockito.when;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.pms.pensionerdetail.model.PensionerDetail;
//import com.pms.pensionerdetail.repository.PensionerRepository;
//import com.pms.pensionerdetail.service.LoadPensionerService;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//class PensionerDetailApplicationTests {
//	
//	@MockBean
//	private PensionerRepository repository;
//	
//	@Autowired
//	private LoadPensionerService service;
//	
//	
//
//	@Test
//	void contextLoads() {
//	}
//
//}
