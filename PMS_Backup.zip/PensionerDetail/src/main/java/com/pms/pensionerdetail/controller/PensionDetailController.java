package com.pms.pensionerdetail.controller;

import org.apache.http.HttpEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.pms.pensionerdetail.model.PensionerDetail;
import com.pms.pensionerdetail.service.LoadPensionerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
class PensionDetailController {

	@Autowired
	private LoadPensionerService service;

	@CrossOrigin(origins = "*")
	@RequestMapping(value="/PensionerDetailByAadhaar/{aadharId}", method=RequestMethod.GET)
	@ApiOperation(value="Get Pensioner By Aadhar",notes="It takes Aadhar number as input and return Pensioner details if the aadhar number and autherization is valid")
	public ResponseEntity<?> getPensionerDetailByAadhar(@ApiParam(value="Unqiue identification key to retrive pensioner",required=true)@PathVariable("aadharId") String aadharId) {
		PensionerDetail detail = service.getPensionerDetailByAadhar(aadharId);
		if(detail!=null){
			log.debug("Successfully provided details for "+aadharId);
			return  ResponseEntity.ok(detail);
		}
		log.info("No data available for "+aadharId);
		return new ResponseEntity(HttpStatus.NOT_FOUND);
	}
}