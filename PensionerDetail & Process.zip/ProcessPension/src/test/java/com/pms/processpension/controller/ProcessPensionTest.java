package com.pms.processpension.controller;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

public class ProcessPensionTest {
	
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void test() {
//		fail("Not yet implemented");
	}

}
