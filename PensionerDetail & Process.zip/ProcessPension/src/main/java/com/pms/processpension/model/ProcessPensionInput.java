package com.pms.processpension.model;

public class ProcessPensionInput {
	private String aadharId;
	
	public ProcessPensionInput() {
	}

	public ProcessPensionInput(String aadharId) {
		this.aadharId = aadharId;
	}

	public String getAadharId() {
		return aadharId;
	}

	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}
	

}
